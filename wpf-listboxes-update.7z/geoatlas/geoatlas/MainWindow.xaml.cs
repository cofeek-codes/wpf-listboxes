﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace geoatlas
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> filenames = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            foreach (RadioButton item in parts_list.Items) {
                item.Checked += Item_Checked;
            }
            foreach (string file in Directory.EnumerateFiles("img", "*"))
            {
                filenames.Add(System.IO.Path.GetFileName(file));
            }
           
            city_cmb.SelectionChanged += City_cmb_SelectionChanged;
        }

        private void City_cmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBox cmb = (ComboBox)sender;

            
            ComboBox combo_selector = (ComboBox)sender;



            string pathPart = filenames[city_cmb.Items.IndexOf(city_cmb.SelectedItem)];


            city_img.Source = new BitmapImage(
    new Uri(@"C:\Users\student\Documents\ИСиП-201\Кормышев Егор\WPF\wpf-listboxes-update\geoatlas\geoatlas\bin\Debug\net5.0-windows\img\"+ pathPart));


        }

        private void Item_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton item = (RadioButton)sender;



        }




    }
}
